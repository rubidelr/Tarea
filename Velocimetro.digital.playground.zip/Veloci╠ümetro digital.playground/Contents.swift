//: Velocímetro digital

import UIKit

enum Velocidades : Int {
    
    case Apagado = 0,  VelocidadBaja = 20, VelocidadMedia = 50, VelocidadAlta = 120
    
    init(){
        
        self = .Apagado
        
    }
    
}


class Auto {
    
    var velocidad = Velocidades()
    
    init(velocidad : Velocidades){
        
    }
    
    func cambioDeVelocidad(contador : Int)->(velocidadActual : Int, mensajeVelocidad : String){
        
        var velocidadMensaje = 0
        var mensaje = ""
        
        if contador == 1{
            velocidadMensaje = velocidad.rawValue
            mensaje = "Apagado"
        }else if contador == 2{
            velocidad = .VelocidadBaja
            velocidadMensaje = velocidad.rawValue
            mensaje = "Velocidad Baja"
        }else if contador % 2 != 0{
            velocidad = .VelocidadMedia
            velocidadMensaje = velocidad.rawValue
            mensaje = "Velocidad Media"
        }else{
            velocidad = .VelocidadAlta
            velocidadMensaje = velocidad.rawValue
            mensaje = "Velocidad Alta"
        }

        let resultado = (velocidadMensaje,mensaje)
    
        return resultado
        
    }
}

var auto = Auto(velocidad : .Apagado)

auto.velocidad


for i in 1...20{
print(auto.cambioDeVelocidad(i))
}



